const packageBuilder = require('../src/createPackage');
const assert = require('assert');
var path = require("path");
var xml2js = require('xml2js');
var vParser = require('fast-xml-parser');
var parser = new xml2js.Parser();

describe('Package Builder Test Empty Object and Mocha Unit Baseline', () => {
    it('should return true if empty', () => {
        assert.equal(packageBuilder.isEmptyObject({}), true);
    });
    it('should return false if not empty', () => {
        assert.equal(packageBuilder.isEmptyObject({'a':'b'}), false);
    });
});

describe('Package Builder Test Package Header', () => {
    let xmlDoc = packageBuilder.buildPackageStandardHeader();
    parser.parseString(xmlDoc, function(err,result){
        it('should return true if all standard header elements exist and set', () => {
            assert.equal(result.package.$.ignoreWarnings, "false");
            assert.equal(result.package.$.author, "#{author}#");
            assert.equal(result.package.$.buildDate.toString().length > 0, true);
            assert.equal(result.package.$.buildNumber, "#{buildNumber}#");
            assert.equal(result.package.$.buildVersion, "#{buildVersion}#");
            assert.equal(result.package.$.img, "xtk:installedPackage.png");
            assert.equal(result.package.$.label, "#{packageLabel}#");
            assert.equal(result.package.$.name, "#{packageName}#");
            assert.equal(result.package.$.namespace, "#{packageNameSpace}#");
            assert.equal(result.package.$.vendor, "");
        });
    });

});


describe('Package Builder Test Get JS/JSSP Data from Repo', () => {
    it('should return false if there is JS data, true otherwise', () => {
        const jsData = packageBuilder.getXMLData(path.join(__dirname, '..\\..') + "\\js\\");
        if (packageBuilder.isEmptyObject(jsData)){
            assert.equal(packageBuilder.isEmptyObject(jsData), true);
        }else{
            assert.equal(packageBuilder.isEmptyObject(jsData), false);
        }

    });

    it('should return true if there is JSSP data, and entity exists in package', () => {
        const jsData = packageBuilder.getXMLData(path.join(__dirname, '..\\..') + "\\jssp\\");
        if (packageBuilder.isEmptyObject(jsData)){
            assert.equal(packageBuilder.isEmptyObject(jsData), true);
        }else{
            assert.equal(packageBuilder.isEmptyObject(jsData), false);
        }

    });
});

describe('Package Builder Test XML for JS/JSSP Entities', () => {
    it('should return true if there is JS data, and entity exists in package', () => {
        const JSData = packageBuilder.getXMLData(path.join(__dirname, '..\\..') + "\\js\\");
        if (packageBuilder.isEmptyObject(JSData)){
            assert.equal(packageBuilder.isEmptyObject(JSData), true);
        }else {
            assert.equal(packageBuilder.isEmptyObject(JSData), false);
            let xmlDoc = packageBuilder.buildPackageStandardHeader();
            packageBuilder.buildEntity(xmlDoc, "javascript", "xtk:javascript", "xtk:javascript.png", "munvo", JSData);
            parser.parseString(xmlDoc, function(err,result){
                assert.equal(result.package.entities[0].$.schema, "xtk:javascript");
            });
        }
    });


    it('should return true if there is JSSP data, and entity exists in package', () => {
        const JSSPData = packageBuilder.getXMLData(path.join(__dirname, '..\\..') + "\\jssp\\");
        if (packageBuilder.isEmptyObject(JSSPData)){
            assert.equal(packageBuilder.isEmptyObject(JSSPData), true);
        }else {
            assert.equal(packageBuilder.isEmptyObject(JSSPData), false);
            let xmlDoc = packageBuilder.buildPackageStandardHeader();
            packageBuilder.buildEntity(xmlDoc, "jssp", "xtk:jssp", "xtk:javascript.png", "munvo", JSSPData);
            parser.parseString(xmlDoc, function(err,result){
                assert.equal(result.package.entities[0].$.schema, "xtk:jssp");
            });
        }
    });
});


describe('Package Builder Valid Package for Deployment', () => {
    it('should return pass if package is built correctly', () => {
        const jsData = packageBuilder.getXMLData(path.join(__dirname, '..\\..') + "\\js\\");
        const jsspData = packageBuilder.getXMLData(path.join(__dirname, '..\\..') + "\\jssp\\");
        let xmlDoc  = packageBuilder.buildRepoPackage(jsData, jsspData).toString({pretty: true});
        assert.equal(vParser.validate(xmlDoc), true);

    });
});


