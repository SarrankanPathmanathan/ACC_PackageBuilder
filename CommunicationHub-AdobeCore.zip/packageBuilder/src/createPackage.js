/**XML Package Builder for Adobe Campaign Classic Import
 * @desc This can be run to create an XML package to include the js and jssp built in a repo
 * Can be imported into ACC. The XML is located in the packageBuilder/out/
 * Currently requires that js files and jssp files be stored in their own directory
 * and that this directory are direct children of the root repo folder
 * @author Sarrankan Pathmanathan sarrankan.pathmanathan@munvo.com
 * @required  npm xmlbuilder
 */

// REQUIRES
var builder = require('xmlbuilder');
var fs = require('fs');
var path = require("path");
var pjson = require('../package.json');
var packageBuilder = {};

/**
 * @desc coreLogin - create an XML for ACC import from the contents of js and jssp directories
 * @return will build the package to import to Adobe Campaign in packageBuilder/out
 */
packageBuilder.coreLogic = function coreLogic() {
    const packageName = pjson.name + ".xml";
    const jsData = packageBuilder.getXMLData(path.join(__dirname, '..\\..') + "\\js\\");
    const jsspData = packageBuilder.getXMLData(path.join(__dirname, '..\\..') + "\\jssp\\");
    fs.writeFile(__dirname+ "\\out\\" + packageName, packageBuilder.buildRepoPackage(jsData, jsspData).toString({pretty: true}), function (err) {
        if (err) return console.log(err);
    });
}

/**
 * @desc buildRepoPackage - Build the XML for ACC for import
 * @param JSData - The filename and contents of the JS to include in XML package
 * @param JSSPData - The filename and contents of the JSSP to include in the XML Package
 * @return will build the package to import to Adobe Campaign in packageBuilder/out
 */
packageBuilder.buildRepoPackage = function buildRepoPackage(JSData,JSSPData) {
    let xmlDoc = packageBuilder.buildPackageStandardHeader();
    packageBuilder.buildEntity(xmlDoc, "javascript", "xtk:javascript", "xtk:javascript.png", "munvo", JSData);
    packageBuilder.buildEntity(xmlDoc, "jssp", "xtk:jssp", "xtk:javascript.png", "munvo", JSSPData);
    return xmlDoc
}

/**
 * @desc buildPackageHeader - Build the XML for ACC for import, must ensure builder number/version
 * correspond to ACC instance
 * @param author - who created the package
 * @param buildNumber - Build Number of ACC instance to import to
 * @param buildVersion -  Build Version of ACC instance to import to
 * @return root XML with package header
 */
packageBuilder.buildPackageStandardHeader = function buildPackageStandardHeader() {
    let xmlDoc  = builder.create('package')
        .att("ignoreWarnings","false")
        .att("author","#{author}#")
        .att("buildDate",new Date().toISOString().replace(/T/, ' '))
        .att("buildNumber", "#{buildNumber}#")
        .att("buildVersion", "#{buildVersion}#")
        .att("img", "xtk:installedPackage.png")
        .att("label", "#{packageLabel}#")
        .att("name", "#{packageName}#")
        .att("namespace", "#{packageNameSpace}#")
        .att("vendor", "");
    return xmlDoc;
}

/**
 * @desc buildEntity - Build an xml entity with data based on attributes
 * currently will support JS and JSSP only.
 * @param xmlDoc - The xml document to build the entity for
 * @param entityType - The type of entity (e.g javascript)
 * @param entitySchema - The type of schema (e.g xtk:javascript)
 * @param img - the image icon type
 * @param namespace - the namespace to build the entity under
 * @param entityData - the CDATA tag of the element. In this case js and jssp code data
 * @return an entity for the xml (currently supports JS and JSSP)
 */
packageBuilder.buildEntity = function buildEntity(xmlDoc,entityType, entitySchema, img, namespace, entityData) {

    if (!packageBuilder.isEmptyObject(entityData)){

        let item = xmlDoc.ele('entities').att("schema",entitySchema);
        for(const property in entityData) {
            var entity = {
                [entityType]: {
                    '@entitySchema': entitySchema,
                    '@img': img,
                    '@label': property,
                    '@name': property,
                    '@namespace': namespace,

                }
            }
            item.ele(entity)
                .ele("data")
                .dat(entityData[property]);

        }

        return xmlDoc
    }

    return '';

}


/**
 * @desc getXMLData - get the CData for the data tag of the XML from JS and JSSP
 * @param dirname - the directories to search for both (e.g js, jssp)
 * @return data object including filename and contents
 */
packageBuilder.getXMLData = function getXMLData(dirname){
    var data = {};
    if (fs.existsSync(dirname))
    {
        var filenames = fs.readdirSync(dirname);
        filenames.forEach(filename => {
            if(filename.split('.').pop().toLowerCase() != "jssp"){
        data[filename.replace(/\.[^/.]+$/, "")] = fs.readFileSync(dirname + "\\" + filename).toString();
    } else
        {
            data[filename] = fs.readFileSync(dirname + "\\" + filename).toString();
        }

    });
    }

    return data;
}


/**
 * SUPPORT FUNCTIONS
 */

/**
 * @desc isEmptyObject - check if object is empty
 * @param obj - and object
 * @return bool - object empty or not
 */
packageBuilder.isEmptyObject = function isEmptyObject(obj) {
    for (var key in obj) {
        if (Object.prototype.hasOwnProperty.call(obj, key)) {
            return false;
        }
    }
    return true;
}


/**
 * MAIN
 */

packageBuilder.coreLogic();
module.exports = packageBuilder;
