if ($PSHOME -like "*SysWOW64*") {
  Write-Warning "Restarting this script under 64-bit Windows PowerShell."

  # Restart this script under 64-bit Windows PowerShell.
  #   (\SysNative\ redirects to \System32\ for 64-bit mode)

  & (Join-Path ($PSHOME -replace "SysWOW64", "SysNative") powershell.exe) -File `
  (Join-Path $PSScriptRoot $MyInvocation.MyCommand) @args

# Exit 32-bit script.

Exit $LastExitCode
}

# Was restart successful?
Write-Warning "  (\SysWOW64\ = 32-bit mode, \System32\ = 64-bit mode)"
Write-Warning "Original arguments (if any): $args"

powershell.exe -Command {& "C:\Program Files (x86)\Adobe\Adobe Campaign v6\bin\nlserver" package -instance:pdr -import:C:\temp\packages\communicationhub-adobecore.xml -verbose}

Exit $LastExitCode