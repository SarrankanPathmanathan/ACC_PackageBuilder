# Introduction 
Any shared framework logic for Munvo/CRx projects will be stored here.
